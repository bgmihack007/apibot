import requests
from telegram import Bot

# Replace these with your actual bot token and chat ID
BOT_TOKEN = '7505991818:AAE2vAD2sB5GeArHWc7vwbz05yLjSXzQTMY'
CHAT_ID = '7423568891'

def check_bin(bot, bin_number):
    message = ""
    # Check if BIN is Visa (starts with 4)
    if str(bin_number).startswith('4'):
        message += f"BIN {bin_number} is a Visa BIN.\n"
        
        # Check if the BIN is VBV (This usually requires a third-party API)
        # Here, we'll simulate a check since actual VBV checks typically involve online services.
        # This is a placeholder for the actual VBV check.
        try:
            response = requests.get(f"https://lookup.binlist.net/{bin_number}")
            if response.status_code == 200:
                data = response.json()
                if data.get("scheme") == "visa" and data.get("prepaid") is False:
                    message += f"BIN {bin_number} is a VBV (Verified by Visa) BIN."
                else:
                    message += f"BIN {bin_number} is not VBV."
            else:
                message += "Failed to retrieve BIN information."
        except Exception as e:
            message += f"Error occurred: {e}"
    else:
        message += f"BIN {bin_number} is not a Visa BIN."

    # Send message to Telegram
    bot.send_message(chat_id=CHAT_ID, text=message)

def main():
    bot = Bot(token=BOT_TOKEN)
    bin_number = input("Enter the BIN number: ")
    check_bin(bot, bin_number)

if __name__ == "__main__":
    main()
